package com.example.neonlyrics;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class NeonLyricsScreen extends Screen {
    public NeonLyricsScreen() {
        super(Text.literal("NeonLyrics Settings"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = Math.max(54, this.height / 5);
        int w = 220;

        addDrawableChild(ButtonWidget.builder(label("HUD", NeonLyricsClient.hudOn()), b -> {
            NeonLyricsClient.toggleHud();
            b.setMessage(label("HUD", NeonLyricsClient.hudOn()));
        }).dimensions(cx - w / 2, y, w, 20).build());

        addDrawableChild(ButtonWidget.builder(label("Lyrics", NeonLyricsClient.lyricsOn()), b -> {
            NeonLyricsClient.toggleLyrics();
            b.setMessage(label("Lyrics", NeonLyricsClient.lyricsOn()));
        }).dimensions(cx - w / 2, y + 26, w, 20).build());

        addDrawableChild(ButtonWidget.builder(label("Glow", NeonLyricsClient.glowOn()), b -> {
            NeonLyricsClient.toggleGlow();
            b.setMessage(label("Glow", NeonLyricsClient.glowOn()));
        }).dimensions(cx - w / 2, y + 52, w, 20).build());

        addDrawableChild(ButtonWidget.builder(label("Visualizer", NeonLyricsClient.visualizerOn()), b -> {
            NeonLyricsClient.toggleVisualizer();
            b.setMessage(label("Visualizer", NeonLyricsClient.visualizerOn()));
        }).dimensions(cx - w / 2, y + 78, w, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Change accent colour"), b -> NeonLyricsClient.nextAccent())
                .dimensions(cx - w / 2, y + 104, w, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Spotify: not connected"), b -> {
            if (client != null) client.setScreen(new InfoScreen());
        }).dimensions(cx - w / 2, y + 130, w, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(cx - w / 2, y + 164, w, 20).build());
    }

    private Text label(String name, boolean enabled) {
        return Text.literal(name + ": " + (enabled ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("NEONLYRICS"), width / 2, 22, NeonLyricsClient.accent);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("HUD and visual settings"), width / 2, 36, 0xFFB7C2D2);
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private static final class InfoScreen extends Screen {
        InfoScreen() {
            super(Text.literal("Spotify connection"));
        }

        @Override
        protected void init() {
            addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> {
                if (client != null) client.setScreen(new NeonLyricsScreen());
            }).dimensions(width / 2 - 100, height / 2 + 20, 200, 20).build());
        }

        @Override
        public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
            renderBackground(ctx, mouseX, mouseY, delta);
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Spotify integration is not configured yet."), width / 2, height / 2 - 12, 0xFFFFFFFF);
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("A Spotify app + OAuth redirect setup is required."), width / 2, height / 2 + 2, 0xFFB7C2D2);
            super.render(ctx, mouseX, mouseY, delta);
        }

        @Override
        public boolean shouldPause() {
            return false;
        }
    }
}
