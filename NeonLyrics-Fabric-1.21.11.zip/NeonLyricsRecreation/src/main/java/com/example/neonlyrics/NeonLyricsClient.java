package com.example.neonlyrics;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class NeonLyricsClient implements ClientModInitializer {
    private static KeyBinding openSettings;
    private static boolean hudEnabled = true;
    static int accent = 0xFF72E7FF;
    static boolean glow = true;
    static boolean showLyrics = true;
    static boolean visualizer = true;

    // Simple time base for animated bars
    private static long startMs = System.currentTimeMillis();

    @Override
    public void onInitializeClient() {
        openSettings = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.neonlyrics_recreation.settings",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openSettings.wasPressed()) {
                client.setScreen(new NeonLyricsScreen());
            }
        });

        // HudRenderCallback is deprecated in favour of HudElementRegistry but still works on 1.21.11
        HudRenderCallback.EVENT.register((context, tickCounter) -> {
            if (hudEnabled) {
                renderHud(context, MinecraftClient.getInstance());
            }
        });
    }

    private static void renderHud(DrawContext ctx, MinecraftClient client) {
        int x = 14;
        int y = client.getWindow().getScaledHeight() - 112;
        int width = 224;
        int height = 98;
        int bg = 0xD9141720;

        // Drop shadow
        ctx.fill(x + 3, y + 3, x + width + 3, y + height + 3, 0x70000000);
        // Card background
        ctx.fill(x, y, x + width, y + height, bg);
        // Accent stripe
        ctx.fill(x, y, x + 3, y + height, accent);

        if (glow) {
            int glowTop = (accent & 0x00FFFFFF) | 0x55000000;
            int glowBot = (accent & 0x00FFFFFF) | 0x33000000;
            ctx.fill(x + 5, y + 5, x + width - 5, y + 6, glowTop);
            ctx.fill(x + 5, y + height - 5, x + width - 5, y + height - 4, glowBot);
        }

        // Album-art placeholder
        ctx.fill(x + 10, y + 10, x + 58, y + 58, 0xFF323D57);
        ctx.fill(x + 15, y + 15, x + 53, y + 53, 0xFF202A3D);
        ctx.drawCenteredTextWithShadow(client.textRenderer, Text.literal("♫"), x + 34, y + 25, accent);

        ctx.drawTextWithShadow(client.textRenderer, Text.literal("NOW PLAYING"), x + 67, y + 10, 0xFF9BA7B8);
        ctx.drawTextWithShadow(client.textRenderer, Text.literal("Blank Space"), x + 67, y + 24, 0xFFFFFFFF);
        ctx.drawTextWithShadow(client.textRenderer, Text.literal("Taylor Swift"), x + 67, y + 38, 0xFFB8C1D0);

        if (showLyrics) {
            ctx.drawTextWithShadow(client.textRenderer, Text.literal("Nice to meet you, where you been?"), x + 10, y + 65, 0xFFEAFBFF);
        }

        if (visualizer) {
            long t = System.currentTimeMillis() - startMs;
            int barCount = 20;
            int bx = x + 10;
            int barColor = (accent & 0x00FFFFFF) | 0xCC000000;
            for (int i = 0; i < barCount; i++) {
                // Pseudo-random animated heights
                double phase = (t / 180.0) + i * 0.55;
                int bh = 4 + (int) (10 * (0.5 + 0.5 * Math.sin(phase)) + 4 * (0.5 + 0.5 * Math.sin(phase * 1.7 + i)));
                if (bh > 18) bh = 18;
                ctx.fill(bx + i * 10, y + height - 8 - bh, bx + i * 10 + 4, y + height - 8, barColor);
            }
        }
    }

    static void toggleHud() { hudEnabled = !hudEnabled; }
    static void toggleLyrics() { showLyrics = !showLyrics; }
    static void toggleGlow() { glow = !glow; }
    static void toggleVisualizer() { visualizer = !visualizer; }
    static boolean hudOn() { return hudEnabled; }
    static boolean lyricsOn() { return showLyrics; }
    static boolean glowOn() { return glow; }
    static boolean visualizerOn() { return visualizer; }

    static void nextAccent() {
        accent = switch (accent) {
            case 0xFF72E7FF -> 0xFFFF8BEA; // pink
            case 0xFFFF8BEA -> 0xFFB4FF82; // green
            default -> 0xFF72E7FF;         // cyan
        };
    }
}
